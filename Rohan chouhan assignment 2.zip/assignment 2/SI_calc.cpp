#include<iostream>
using namespace std;
int main(){
int P=10;
int R=20;
int T=60;
cout<<(P*R*T)/100;
}