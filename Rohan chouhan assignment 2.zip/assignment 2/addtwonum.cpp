#include<iostream>
using namespace std;
int main(){
int a=10;
int b=20;
cout<<a+b;
}