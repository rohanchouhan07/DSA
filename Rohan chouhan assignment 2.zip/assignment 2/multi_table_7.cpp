#include<iostream>
using namespace std;
int main()
{
    int i,n=7;
    //cout<<"Enter the number :";
   // cin>>n;
    for(i=1;i<=10;i++){
        cout<<i<<" * "<<n<<" = "<<i*7<<endl;
    }
    return 0 ;
}