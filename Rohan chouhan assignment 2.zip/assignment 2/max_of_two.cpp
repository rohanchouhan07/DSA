#include<iostream>
using namespace std;
int main(){
int a; cin>>a;
int b=20; cin>>b;
if(a>b){
    cout<<"A Greater";
}
else{
    cout<<"B Greater";
}
}